<template>
	<modal class="contact-customer-service-page" :visible="true">
		<div>联系我们</div>
	</modal>
</template>