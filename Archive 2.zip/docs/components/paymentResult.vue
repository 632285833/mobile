 <template>
 	<div class="payment-result-page table-list-container page">
 		<ul class="table-list">
 			<li>
 				<div class="title-view color-primary">分享产品</div>
 			</li>
 			<router-link to="orderDetail" tag="li">
 				<div class="title-view color-primary">查看订单</div>
 			</router-link>
 			<router-link to="/" tag="li">
 				<div class="title-view color-primary">返回首页</div>
 			</router-link>
 		</ul>
 	</div>
 </template>