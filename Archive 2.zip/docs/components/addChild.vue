<template>
	<div class="add-child-page table-list-container page">
		<ul class="table-list">
			<li>
				<div class="u-input">
					<div class="input-title">萌宝性别</div>
					<ul class="array-list double-column content-view" v-toggleList>
						<li>男宝</li>
						<li>女宝</li>
					</ul>
				</div>
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">姓名（必填）</div>
					<input>
				</div>
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">出生年月</div>
					<input>
				</div>
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">身份证号</div>
					<input>
				</div>
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">爱好特长</div>
				</div>
				<ul class="array-list quad-column content-view" v-checkList>
					<li>音乐</li>
					<li>游泳</li>
					<li>阅读</li>
					<li>玩沙</li>
					<li>积木</li>
					<li>自定义</li>
				</ul>
			</li>
		</ul>
		<footerBar class="solo">
			<uButton class="save-button" :path="'paymentResult'">保存</uButton>
		</footerBar>
	</div>
</template>