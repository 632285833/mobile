<template>
	<div class="tab-bar-controller">
		<router-view></router-view>
	</div>
</template>
