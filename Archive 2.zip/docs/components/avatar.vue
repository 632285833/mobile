<template>
	<div class="avatar-page table-list-container page">
		<ul class="table-list">
			<li>
				<div class="title-view">昵称</div>
				<div class="content-view">Robin</div>
			</li>
			<li>
				<div class="title-view">微信号</div>
				<div class="content-view"><span>Robincp</span><span class="inline-label">已绑定</span></div>
			</li>
			<li>
				<div class="title-view">手机号</div>
				<div class="content-view"><span>13798098870</span><span class="inline-label">已绑定</span></div>
			</li>



		</ul>
	</div>
</template>
