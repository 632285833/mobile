<template>
	<div class="product-specs-page table-list-container page">
		<ul class="table-list">
		    <li>
				<div class="title-view">套餐</div>
				<div class="content-view">
					<ul class="array-list triple-column" v-toggleList>
						<li>套餐一</li>
						<li>套餐二</li>
						<li>套餐三<span>六</span></li>
					</ul>
				</div>
			</li>
			<li>
				<div class="title-view">活动日期</div>
				<div class="content-view">
					<ul class="array-list triple-column" v-toggleList>
						<li>今天</li>
						<li>明天</li>
						<li>1月12日<span>六</span></li>
						<li>1月13日<span>日</span></li>
						<li>1月20日<span>六</span></li>
						<li>1月21日<span>日</span></li>
						<li>1月28日</li>
						<li>1月29日</li>
						<li>其他日期</li>
					</ul>
				</div>
			</li>
			<li>
				<div class="title-view">活动场次</div>
				<div class="content-view">
					<ul class="array-list double-column" v-toggleList>
						<li>10:00-12:00</li>
						<li>14:00-16:00</li>
					</ul>
				</div>
			</li>
			<li>
				<div class="title-view">参与人群</div>
				<div class="content-view">
					<ul class="array-list double-column" v-toggleList>
						<li>2大人1儿童</li>
						<li>1大人1儿童</li>
					</ul>
				</div>
			</li>
			<li class="space-between-center">
				<div class="title-view">购买数量</div>
				<numSpinner></numSpinner>

			</li>
		</ul>
		<footerBar>
			<div class="flex-grow"><span class="color-light">订单总额：</span>￥1038</div>
			<uButton :path="'mobileVerification'">下一步</uButton>
		</footerBar>
	</div>
</template>