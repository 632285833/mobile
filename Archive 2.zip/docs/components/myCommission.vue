<template>
	<div class="talent-detail-page"></div>
</template>