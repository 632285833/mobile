<template>
	<div class="product-list-page table-list-container">
	    <modal 
	    @close="closeModal('dataModalVisible')" 
	    :visible="boolList['dataModalVisible']" 
	    :isFullHeight="true"
	    >
	    </modal>
	     <modal 
	    @close="closeModal('sortModalVisible')" 
	    :visible="boolList['sortModalVisible']" 
	    :title="'排序方式'"
	    :isFullHeight="true"
	    ref="sortModal"
	    >
	    <div class="table-list-container">
	        <div class="u-title">排序方式</div>
	    	<ul class="table-list" v-toggleList:sortModalVisible.first="closeSortModal" ref="aaa">
	    		<li><div class="title-view">默认排序</div></li>
	    		<li><div class="title-view">即将开始</div></li>
	    		<li><div class="title-view">底价排序</div></li>
	    		<li><div class="title-view">高价排序</div></li>
	    		<li><div class="title-view">佣金排序</div></li>
	    	</ul>
	    </div>
	    </modal>
	     <modal 
	    @close="closeModal('filterModalVisible')" 
	    :visible="boolList['filterModalVisible']" 
	    :isFullHeight="true"
	    >
	    <div class="table-list-container">
	    <div class="u-title">筛选条件</div>
	    	<ul class="table-list">
	    		<li>
	    		    <div class="title-view">产品类型</div>
	    		    <div class="content-view">
						<ul class="array-list triple-column" v-checkList>
							<li v-for="type in typeList" :key="type.id">{{type}}</li>
						</ul>
					</div>
	    		</li>
	    		<li>
	    		    <div class="title-view">年龄段</div>
	    		    <div class="content-view">
	    		    	<ul class="array-list triple-column" v-checkList>
							<li>1-3岁</li>
							<li>3-5岁</li>
							<li>5-7岁</li>
							<li>7-9岁</li>
							<li>10岁以上</li>
						</ul>
	    		    </div>
	    		</li>
	    		<li>
	    		    <div class="title-view">产品类型</div>
	    		    <div class="content-view">
						<ul class="array-list triple-column" v-checkList>
							<li v-for="type in typeList" :key="type.id">{{type}}</li>
						</ul>
					</div>
	    		</li>
	    		<li>
	    		    <div class="title-view">年龄段</div>
	    		    <div class="content-view">
	    		    	<ul class="array-list triple-column" v-checkList>
							<li>1-3岁</li>
							<li>3-5岁</li>
							<li>5-7岁</li>
							<li>7-9岁</li>
							<li>10岁以上</li>
						</ul>
	    		    </div>
	    		</li>
	    	</ul>
	    	<footerBar class="solo">
			<uButton class="save-button" :path="'paymentResult'">保存</uButton>
		</footerBar>
	    </div>
	    </modal>
		<div class="u-title space-between">
			<span>{{navTitle}}</span>
			<div class="filter-container space-between">
				<span @click="toggle('dataModalVisible')">日期</span>
			    <span @click="toggle('sortModalVisible')">排序</span>
			    <span @click="toggle('filterModalVisible')">筛选</span>
			</div>
		</div>
		<ul class="card-item-list">
				<router-link v-for="product in productArr" to="productDetail" tag="li" :key="product.id">
					<div class="img-container" aspect-ratio="28:58">
						<img :src="product.img" v-trimImg.width>
					</div>
					<div class="item-info-container">
						<div class="item-name">
							{{product.name}}
							<span class="inline-label" v-for="label in product.labelList">{{label}}</span>
						</div>
						<div class="item-group" style="margin-top:0.2rem">
							<span class="starting-price">{{product.price}}</span>
							<span class="color-light">{{product.sales}}人已报名</span>
						</div>
					</div>
			</router-link>
		</ul>
	</div>
</template>
<script>
    import Emitter from 'src/mixins/emitter';
	export default {
		mixins: [ Emitter ],
		computed: {
			navTitle: function() {
				if (this.$route.query.navTitle) {
					return this.$route.query.navTitle
				} else {
					return '全部产品'
				}
			},
			productArr: function() {
				if (this.$route.query.navTitle) {
					return this.$route.query.productArr;
				} else {
					return this.productArrs
				}
			}
		},
		data() {
			return {
                typeList: ['全部', '社会实践', '贵族运动', '户外运动', '科学探索', '音乐之旅'],
				boolList: { dataModalVisible: false, sortModalVisible: false, filterModalVisible: false },
				productArrs: [{
					img: 'static/attachment/product1.png',
					labelList: ['乐园', '2-5岁'],
					name: '希望在田野，回归大自然',
					posi: '福田区欢乐海岸 距8.9km',
					price: '898',
					sales: 273,

				},{
					img: 'static/attachment/product2.png',
					labelList: ['乐园', '2-5岁'],
					name: '科考营-国家地理杂志的探索团队严肃的带你入“坑”',
					posi: '福田区欢乐海岸 距8.9km',
					price: '688',
					sales: 190,

				},{
					img: 'static/attachment/product3.png',
					labelList: ['科学秀', '5-8岁'],
					name: '羽蒙科学秀-自营爆款之《冰火奇遇记》科学探索奇妙世界',
					posi: '福田区欢乐海岸 距8.9km',
					price: 898,
					sales: 835,

				},{
					img: 'static/attachment/product4.png',
					labelList: ['亲子照'],
					name: '金夫人in爱 亲子全家照，疯抢价 38.9元',
					posi: '福田区欢乐海岸 距8.9km',
					price: '189',
					sales: 674,

				},{
					img: 'static/attachment/product5.png',
					labelList: ['乐园', '2-5岁'],
					name: 'G4小记者小主播培训，全广州招募100位电视小天使！',
					posi: '福田区欢乐海岸 距8.9km',
					price: '1089',
					sales: 892,

				},{
					img: 'static/attachment/product6.png',
					labelList: ['科学秀', '8岁以上'],
					name: '世界记忆大师亲临，高效学习方法免费公开课，场场爆满，你还在等什么？',
					posi: '福田区欢乐海岸 距8.9km',
					price: 99,
					sales: 683,

				},{
					img: 'static/attachment/product7.png',
					labelList: ['探秘', '2-5岁'],
					name: '带娃探秘神秘岛，离广州仅1小时的距离！',
					posi: '福田区欢乐海岸 距8.9km',
					price: '178',
					sales: 1848,

				},]
			}
		},

		methods: {
			toggle(bool) {
			    this.boolList[bool] = !this.boolList[bool]
			},
			closeSortModal() {
				var _this = this;
				setTimeout(function() {
					_this.$refs.sortModal.close();
				},200)
			},
			closeModal(bool) {
				this.boolList[bool] = false
			}
		},
	}
</script>