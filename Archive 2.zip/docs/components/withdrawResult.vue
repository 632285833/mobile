 <template>
 	<div class="withdraw-result-page table-list-container page">
 		<ul class="table-list">
 			<li>
 				<div class="color-light">24小时内，我们会微信或电话联系你，将金额转到您的微信里，请注意查收</div>
 			</li>
 			<router-link to="iAmTalent" tag="li">
 				<div class="title-view color-primary">返回达人中心</div>
 			</router-link>
 			<router-link to="/" tag="li">
 				<div class="title-view color-primary">返回首页</div>
 			</router-link>
 		</ul>
 	</div>
 </template>