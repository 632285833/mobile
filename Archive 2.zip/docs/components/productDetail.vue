<template>
	<div class="product-detail-page">
		<modal :visible="boolList['contactVisible']" :isFullHeight="true" @close="toggle('contactVisible')" >
			<div class="contact-service h-v-center">
				<img src="static/attachment/QR-code.png">
				<div>扫码联系客服</div>
			</div>
		</modal>
		<navBar class="black-gradient-mask"><div><uSVG viewBox="0 0 10 4" :id="'#i-heart'" class="stroke"></uSVG></div></navBar>
		<div class="product-detail-content">
			<div class="img-container bridge-gradient-mask" aspect-ratio="1:2">
				<img :src="product.img" v-trimImg>
			</div>
			<div class="product-info-wrap table-list-container">

				<ul class="product-info-list table-list">
					<li>
						<div class="title-view">
							{{product.name}}
							<span class="inline-label" v-for="label in product.labelList">{{label}}</span>
						</div>
						<div class="content-view space-between">
							<span class="starting-price-large">{{product.price}}</span>
						</div>
					</li>
					<li>
						<div class="title-view">{{product.sales}}人已报名</div>
						<div class="content-view item-group avatar-list" ref="avatarList">
							<img v-for="avatar in product.avatarList" :src="avatar" class="involved-avatar">
						</div>

					</li>
					<li class="">
						<div class="title-view">活动时间</div>
						<div class="content-view">1月6日周六起</div>
						<svg viewBox="0 0 10 2.5" class="stroke i-arrow">
							<use xlink:href="#i-arrow"></use>
						</svg>
					</li>
					<li class="">
						<div class="title-view">活动地点</div>
						<div class="content-view">{{product.posi}}</div>
						<svg viewBox="0 0 10 2.5" class="stroke i-arrow">
							<use xlink:href="#i-arrow"></use>
						</svg>
					</li>

					<li>
						<div class="title-view">产品介绍</div>
						<div class="content-view">
							沙盘心理游戏<br>
							探索孩子内心不愿意说的秘密<br>
							探索孩子内心不可不知的秘密<br>
							探索孩子内心世界<a class="text-button">查看更多</a>
						</div>
					</li>
					<li>
						<div class="title-view">预订须知</div>
						<div class="content-view">
							有效时间：使用日期1日内有效,每天的19:30-21:30可使用<br>
							购买时间：请至少当天17点20分前购买<br>
							购买限制：同一身份证在1天内最多只能预订5张；同一手机号在1天内最多只能预订5张<br>
						</div>
					</li>
				</ul>
			</div>
			<footerBar isAnimated="true">
				<div class="contact-button color-light" @click="toggle('contactVisible')">联系客服</div>
				<uButton class="share-button">分享赚5元</uButton>
				<uButton :path="'navBarView/productSpecs'">立即报名</uButton>
			</footerBar>
		</div>
	</div>
</template>
<script>
	export default {
		data() {
			return {
				product: {
					img: 'static/attachment/product2.png',
					labelList: ['乐园', '2-5岁'],
					name: '科考营-国家地理杂志的探索团队严肃的带你入“坑”',
					posi: '福田区欢乐海岸 距8.9km',
					price: '898',
					sales: 273,
					avatarList: ['static/attachment/avatar1.png','static/attachment/avatar2.png','static/attachment/avatar3.png','static/attachment/avatar4.png','static/attachment/avatar5.png','static/attachment/avatar6.png','static/attachment/avatar1.png','static/attachment/avatar2.png','static/attachment/avatar3.png','static/attachment/avatar4.png','static/attachment/avatar5.png','static/attachment/avatar6.png'],
				},
				boolList: {contactVisible: false}
			}
		},
		methods: {
			snap() {

				// var avatarList = this.$refs.avatarList;
				// var w = avatarList.offsetWidth;
				// var unit_w = avatarList.children[0].offsetWidth;
				// var scrollLeft = avatarList.scrollLeft;
				// // avatarList.scroll(100, 0);
				// var marginLeft = avatarList.children[1].getStyle('marginLeft').replace(/px/g, '');
			 //    var remainder = (scrollLeft-unit_w)%(unit_w+marginLeft);
			 //    console.log(remainder)
			},
			toggle(bool) {
				this.boolList[bool] = !this.boolList[bool]
			}
		},
		mounted() {
			var _this = this;
			var scrollTimer;
			this.$refs.avatarList.addEventListener('scroll', ()=>{
				clearTimeout(scrollTimer)
				scrollTimer = setTimeout(_this.snap, 100);
			})
		}
	}
</script>