<template>
	<div class="add-adult-page table-list-container page">
		<ul class="table-list">
			<li>
				<div class="u-input">
					<div class="input-title">角色</div>
					<div class="content-view">
						<ul class="array-list triple-column" v-toggleList>
							<li>萌爸</li>
							<li>萌妈</li>
							<li>其他</li>
						</ul>
					</div>
				</div>
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">姓名（必填）</div>
					<input>
				</div>
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">手机号（必填）</div>
					<input>
				</div>
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">身份证号</div>
					<input>
				</div>
			</li>
		</ul>
		<footerBar class="solo">
			<uButton class="save-button" :path="'paymentResult'">保存</uButton>
		</footerBar>
	</div>
</template>