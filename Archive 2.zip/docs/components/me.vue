<template>
	<div class="me-page table-list-container">
		<ul class="table-list">
			<router-link tag="li" to="navBarView/avatar" class="avatar-container">
				<div class="title-view">
					<div class="avatar-wrapper">
					    <span class="avatar-desc">R</span>
					    <img src="static/attachment/product6.png" v-trimImg>
					</div>
					<span class="user-name">Robin</span>
				</div>
				<svg  viewBox="0 0 10 2.5" class="i-arrow"><use xlink:href="#i-arrow"></use></svg>
			</router-link>
			<router-link tag="li" to="navBarView/iAmTalent">
				<div class="title-view">达人中心</div>
				<div class="right-view">累积佣金2124.8</div>
				<svg  viewBox="0 0 10 2.5" class="i-arrow"><use xlink:href="#i-arrow"></use></svg>
			</router-link>
			<router-link tag="li" to="navBarView/myOrders">
			    <div class="title-view item-group"><span>我的订单</span><span class="num-tip">4</span></div>
				<svg  viewBox="0 0 10 2.5" class="i-arrow"><use xlink:href="#i-arrow"></use></svg>
			</router-link>
			<router-link tag="li" to="navBarView/myFamily">
				<div class="title-view">我的家人</div>
				<svg  viewBox="0 0 10 2.5" class="i-arrow"><use xlink:href="#i-arrow"></use></svg>
			</router-link>
			<router-link tag="li" to="navBarView/myCollections">
				<div class="title-view">我的收藏</div>
				<svg  viewBox="0 0 10 2.5" class="i-arrow"><use xlink:href="#i-arrow"></use></svg>
			</router-link>
			<router-link tag="li" to="navBarView/contactUs">
				<div class="title-view">联系羽蒙</div>
				<svg  viewBox="0 0 10 2.5" class="i-arrow"><use xlink:href="#i-arrow"></use></svg>
			</router-link>
		</ul>
	</div>
</template>
