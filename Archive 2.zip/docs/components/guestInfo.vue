<template>
	<div class="guest-info-page table-list-container page">
		<ul class="table-list">
			<li class="space-between-center">
				<div class="title-view"><span>周川平</span><span class="inline-label">萌爸</span></div>
				<div class="right-view">删除</div>
			</li>
			<li class="space-between-center">
				<div class="title-view"><span>周翼开</span><span class="inline-label">萌娃</span></div>
				<div class="right-view">删除</div>
			</li>
			<li to="guestList" class="space-between-center" @click="handleClick">
				<div class="title-view color-primary">选择客人</div>
			</li>
		</ul>
		<footerBar>
			<div class="flex-grow"><span class="color-light">订单总额：</span>￥1038</div>
			<uButton :path="'myAddress'">提交订单</uButton>
		</footerBar>
	</div>
</template>
<script>
	export default {
		methods: {
			handleClick() {
				this.$router.push({path: 'myFamily', query: {isSelectGuests: true}});
			}
		}
	}
</script>
