<template>
	<div class="contact-us-page table-list-container page">
				<div class="content-view">
					<div class="contact-service h-v-center">
						<img src="static/attachment/QR-code.png">
				        <div>扫码联系客服</div>
					</div>
				</div>
	</div>
</template>