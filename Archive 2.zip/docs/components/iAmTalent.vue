<template>
	<div class="talent-page table-list-container page">
		<ul class="table-list">
		    <router-link tag="li" to="commissionDetail">
		        <div class="title-view space-between">
			        <span>我的收益</span>
			        <span class="color-primary font-normal">查看详情</span>
			    </div>
			    <ul class="content-view space-between text-center">
			    	<li>
			    	    <div class="font-max color-warning">$2132.2</div>
			    		<div class="color-light font-small">累计总收益</div>
			    	</li>
			    	<li>
			    	    <div class="font-max color-warning">$247</div>
			    		<div class="color-light font-small">可提现</div>
			    	</li>
			    	<li>
			    	    <div class="font-max color-warning">$1685</div>
			    		<div class="color-light font-small">未结算</div>
			    	</li>
			    </ul>
			</router-link>
			<router-link tag="li" to="myShare">
			    <div class="title-view space-between">
			        <span>我的分享</span>
			        <span class="color-primary font-normal">快去分享</span>
			    </div>
			    <div class="content-view">已分享30个产品，可得佣金 163</div>
			</router-link>
			
			<router-link tag="li" to="myTalents">
			    <div class="title-view space-between">
			        <span>我的达人</span>
			        <span class="color-primary font-normal">邀请达人</span>
			    </div>
			    <div class="content-view">已分享30个产品，可得佣金 982</div>
			</router-link>
			
		</ul>
	</div>
</template>