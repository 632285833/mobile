<template>
	<div class="my-address-page table-list-container page">
		<ul class="table-list">
			<li>
				<div class="u-input">
					<div class="input-title">收件人</div>
					<input>
				</div>
				
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">手机号</div>
					<input>
				</div>
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">所在地区</div>
					<input>
				</div>
			</li>
			<li>
				<div class="u-input">
					<div class="input-title">详细地址</div>
					<input>
				</div>
			</li>
		</ul>
		<footerBar>
			<div class="flex-grow"><span class="color-light">订单总额：</span>￥1038</div>
			<uButton :path="'payment'">下一步</uButton>
		</footerBar>
	</div>
</template>