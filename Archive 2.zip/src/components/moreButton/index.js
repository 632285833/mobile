import moreButton from './moreButton';
export default moreButton;