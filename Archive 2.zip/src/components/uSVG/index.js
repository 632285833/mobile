import uSVG from './uSVG';
export default uSVG;
