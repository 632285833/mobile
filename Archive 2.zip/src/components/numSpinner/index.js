import numSpinner from './numSpinner';
export default numSpinner;
