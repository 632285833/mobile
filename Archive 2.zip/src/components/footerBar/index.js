import footerBar from './footerBar';
export default footerBar;
