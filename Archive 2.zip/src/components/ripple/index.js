import Ripple from './Ripple';
export default Ripple;
