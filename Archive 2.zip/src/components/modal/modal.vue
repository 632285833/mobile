<template>
	<div class="modal-container" v-show="visible">
		<transition name="push">
			<div class="modal" :class="{ 'full-height': isFullHeight }" v-show="modalVisble">
				<div class="header" v-show="headerVisible">
					<div @click="close">
						<uSVG viewBox="0 0 2 1.1" :id="'#i-cross'" class="close-button"></uSVG>
					</div>
					<div class="right-view color-complement bold">{{ action }}</div>
				</div>
				<div class="body">
					<slot></slot>
				</div>
			</div>
		</transition>
		<transition name="fade">
			<div class="modal-coat" v-show="modalVisble" @click="close">
			</div>
		</transition>
	</div>
</template>
<script>
	export default {
		name: 'modal',
		props: {
			headerVisible: {
				type: Boolean,
				default: true
			},
			isFullHeight: {
				type: Boolean,
				default: false
			},
			visible: {
				type: Boolean,
				default: false
			},
			action: {
				type: String,
				default: ''
			}
		},
		data() {
			return {
				modalVisble: false
			}
		},
		watch: {
			visible(newVal, oldVal) {
				this.modalVisble = newVal
			}

		},
		methods: {
			handleCancel() {
				this.close()
			},
			close() {
				var self = this
				this.modalVisble = false
				setTimeout(function(){
					self.$emit('close')
				},500)
			}
		}

	}
</script>
<style lang="scss" scoped>
	@import '../../../docs/scss/variables.scss';
	.push-enter-active, .push-leave-active, .fade-enter-active, .fade-leave-active {
		transition: all .35s;
	}
	.push-enter, .push-leave-to {
		transform: translateY(100%);
	}
	.fade-enter, .fade-leave-to {
		opacity: 0;
	}

</style>