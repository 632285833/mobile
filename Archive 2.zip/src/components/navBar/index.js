import navBar from './navBar';
export default navBar;
